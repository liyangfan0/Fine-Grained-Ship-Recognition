# Copyright (c) OpenMMLab. All rights reserved.
from .convex_giou_loss import BCConvexGIoULoss, ConvexGIoULoss
from .gaussian_dist_loss import GDLoss
from .gaussian_dist_loss_v1 import GDLoss_v1
from .kf_iou_loss import KFLoss
from .kld_reppoints_loss import KLDRepPointsLoss
from .smooth_focal_loss import SmoothFocalLoss
from .rotated_iou_loss import RotatedIoULoss

__all__ = [
    'GDLoss', 'GDLoss_v1', 'KFLoss', 'ConvexGIoULoss', 'BCConvexGIoULoss',
    'KLDRepPointsLoss', 'SmoothFocalLoss','RotatedIoULoss'
]
