import torch
from mmrotate.core.bbox.assigners.atss_obb_assigner_v4 import ATSSObbAssigner






self=ATSSObbAssigner(topk=2)
pred_scores=torch.rand(6,4).cuda() #shape (n, num_classes)
decode_boxes=torch.Tensor([[0,0,8,8,3],[5,5,15,15,8],[9,9,10,10,4],[3,5,15,15,4],[2,7,10,10,9],[2,3,5,6,8]]).cuda()
bboxes=torch.Tensor([[0,0,10,10,3],[10,10,20,20,8],[9,9,15,15,4],[3,5,20,20,4],[2,7,15,15,9],[2,3,5,6,8]]).cuda()
num_level_bboxes=[3,3]
gt_bboxes=torch.Tensor([[1,1,8,8,3],[0,0,10,10,2],[3,5,20,20,3]]).cuda()
gt_labels=torch.LongTensor([1,2,3]).cuda()
assign_result=self.assign(pred_scores,decode_boxes,bboxes,num_level_bboxes,gt_bboxes,gt_labels=gt_labels)
print(assign_result.max_overlaps)
print(assign_result.gt_inds)
print(assign_result.labels)
print(assign_result.assign_metrics)


'''
import torch
from mmrotate.models.dense_heads.rotated_anchor_head import RotatedAnchorHead
self=RotatedAnchorHead(num_classes=3,in_channels=256)
num_anchors=3
num_classes=3
cls_scores=[torch.rand(3,num_anchors*num_classes,s,s) for s in [4,8,16,32,64]]
bbox_preds=[torch.rand(3,num_anchors*num_classes,s,s) for s in [4,8,16,32,64]]

gt_bboxes=[torch.rand(num_gts,5) for num_gts in [10,20,30]]
gt_labels=[torch.rand(num_gts,) for num_gts in [10,20,30]]

img_metas=[{'img_shape':(128,128,3),'scale_factor':1,'pad_shape':(32,32)}]

my_loss=self.loss(cls_scores,bbox_preds,gt_bboxes,gt_labels,img_metas)
print(my_loss)
'''