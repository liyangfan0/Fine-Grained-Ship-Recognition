
def test():
    print ("hello world")

if __name__ == '__main__':
    test()