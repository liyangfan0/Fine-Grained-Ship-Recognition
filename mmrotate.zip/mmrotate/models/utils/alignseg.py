#import encoding.nn as nn
#import encoding.functions as F
import torch.nn as nn
from torch.nn import functional as F
import math
import torch.utils.model_zoo as model_zoo
import torch
import numpy as np

import functools

import sys, os

from mmcv.ops import DeformConv2d
from .CBAM import SpatialAttention
from .CBAM import ChannelAttention
#from inplace_abn import InPlaceABN, InPlaceABNSync
#BatchNorm2d = functools.partial(InPlaceABNSync, activation='identity')

def conv3x3(in_planes, out_planes, stride=1):
    "3x3 convolution with padding"
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=1, bias=False)


class Bottleneck(nn.Module):
    expansion = 4
    def __init__(self, inplanes, planes, stride=1, dilation=1, downsample=None, fist_dilation=1, multi_grid=1):
        super(Bottleneck, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride,
                               padding=dilation*multi_grid, dilation=dilation*multi_grid, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, planes * 4, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(planes * 4)
        self.relu = nn.ReLU(inplace=False)
        self.relu_inplace = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.dilation = dilation
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out = out + residual      
        out = self.relu_inplace(out)

        return out

class RRB(nn.Module):

    def __init__(self, features, out_features=512):
        super(RRB, self).__init__()

        self.unify = nn.Conv2d(features, out_features, kernel_size=1, padding=0, dilation=1, bias=False)
        self.residual = nn.Sequential(nn.Conv2d(out_features, out_features//4, kernel_size=3, padding=1, dilation=1, bias=False),
                                    nn.BatchNorm2d(out_features//4),
                                    nn.Conv2d(out_features//4, out_features, kernel_size=3, padding=1, dilation=1, bias=False))
        self.norm = InPlaceABNSync(out_features)

    def forward(self, feats):
        feats = self.unify(feats)
        residual = self.residual(feats)
        feats = self.norm(feats + residual)
        return feats

class CAM(nn.Module):
    def __init__(self, features, in_features):
        super(CAM, self).__init__()

        self.pool = nn.Sequential(
                        nn.AdaptiveAvgPool2d(output_size=(3, 3)),
                        nn.Conv2d(features, features, kernel_size=1, bias=False),
                        nn.BatchNorm2d(features),
                        nn.Conv2d(features, in_features, kernel_size=3, padding=1, bias=False),
                        nn.BatchNorm2d(in_features))

        self.adapt = nn.Sequential(
                        nn.Conv2d(features, features, kernel_size=1, bias=False),
                        nn.BatchNorm2d(features),
                        nn.Conv2d(features, in_features, kernel_size=3, padding=1, bias=False),
                        nn.BatchNorm2d(in_features))


        self.delta_gen = nn.Sequential(
                        nn.Conv2d(in_features*2, in_features, kernel_size=1, bias=False),
                        nn.BatchNorm2d(in_features),
                        nn.Conv2d(in_features, 2, kernel_size=3, padding=1, bias=False)
                        )
        self.delta_gen[2].weight.data.zero_()

    # https://github.com/speedinghzl/AlignSeg/issues/7
    # the normlization item is set to [w/s, h/s] rather than [h/s, w/s]
    # the function bilinear_interpolate_torch_gridsample2 is standard implementation, please use bilinear_interpolate_torch_gridsample2 for training.
    def bilinear_interpolate_torch_gridsample(self, input, size, delta=0):
        out_h, out_w = size
        n, c, h, w = input.shape
        s = 1.0
        norm = torch.tensor([[[[w/s, h/s]]]]).type_as(input).to(input.device)
        w_list = torch.linspace(-1.0, 1.0, out_h).view(-1, 1).repeat(1, out_w)
        h_list = torch.linspace(-1.0, 1.0, out_w).repeat(out_h, 1)
        grid = torch.cat((h_list.unsqueeze(2), w_list.unsqueeze(2)), 2)
        grid = grid.repeat(n, 1, 1, 1).type_as(input).to(input.device)
        grid = grid + delta.permute(0, 2, 3, 1) / norm

        output = F.grid_sample(input, grid)
        return output

    def bilinear_interpolate_torch_gridsample2(self, input, size, delta=0):
        out_h, out_w = size
        n, c, h, w = input.shape
        s = 2.0
        norm = torch.tensor([[[[(out_w-1)/s, (out_h-1)/s]]]]).type_as(input).to(input.device) # not [h/s, w/s]
        w_list = torch.linspace(-1.0, 1.0, out_h).view(-1, 1).repeat(1, out_w)
        h_list = torch.linspace(-1.0, 1.0, out_w).repeat(out_h, 1)
        grid = torch.cat((h_list.unsqueeze(2), w_list.unsqueeze(2)), 2)
        grid = grid.repeat(n, 1, 1, 1).type_as(input).to(input.device)
        grid = grid + delta.permute(0, 2, 3, 1) / norm

        output = F.grid_sample(input, grid, align_corners=True)
        return output

    def forward(self, low_stage):
        n, c, h, w = low_stage.shape
        high_stage = self.pool(low_stage)
        low_stage = self.adapt(low_stage)

        high_stage_up = F.interpolate(input=high_stage, size=(h, w), mode='bilinear', align_corners=True)
        concat = torch.cat((low_stage, high_stage_up), 1)
        delta = self.delta_gen(concat)
        high_stage = self.bilinear_interpolate_torch_gridsample(high_stage, (h, w), delta)

        high_stage += low_stage

        return high_stage

# 定义偏移量生成网络（通常是一个标准卷积层）
class OffsetGenerator(nn.Module):
    def __init__(self, in_channels, kernel_size):
        super(OffsetGenerator, self).__init__()
        self.conv = nn.Conv2d(in_channels, 2 * kernel_size * kernel_size, kernel_size=3, padding=1)

    def forward(self, x):
        return self.conv(x)

# 定义包含 DeformConv2d 的网络
class DeformableConvNet(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3):
        super(DeformableConvNet, self).__init__()
        self.offset_generator = OffsetGenerator(in_channels, kernel_size)
        self.deform_conv = DeformConv2d(in_channels, out_channels, kernel_size, padding=1)

    def forward(self, x):
        offset = self.offset_generator(x)  # 生成偏移量
        out = self.deform_conv(x, offset)  # 使用 DeformConv2d
        return out

class CAB(nn.Module):
    def __init__(self, features):
        super(CAB, self).__init__()

        self.offset_generator = OffsetGenerator(features*2, kernel_size=3)
        self.deform_conv = DeformConv2d(features, features, kernel_size=3, padding=1)
        '''
        self.deform_conv = DeformConv2d(
            features,
            features,
            kernel_size=3,
            padding=(3 - 1) // 2,
            deform_groups=1)
        self.relu = nn.ReLU(inplace=True)
        #self.delta_gen2[2].weight.data.zero_()
        '''

    # https://github.com/speedinghzl/AlignSeg/issues/7
    # the normlization item is set to [w/s, h/s] rather than [h/s, w/s]
    # the function bilinear_interpolate_torch_gridsample2 is standard implementation, please use bilinear_interpolate_torch_gridsample2 for training.
    def bilinear_interpolate_torch_gridsample(self, input, size, delta=0):
        out_h, out_w = size
        n, c, h, w = input.shape
        s = 1.0
        norm = torch.tensor([[[[w/s, h/s]]]]).type_as(input).to(input.device)
        w_list = torch.linspace(-1.0, 1.0, out_h).view(-1, 1).repeat(1, out_w)
        h_list = torch.linspace(-1.0, 1.0, out_w).repeat(out_h, 1)
        grid = torch.cat((h_list.unsqueeze(2), w_list.unsqueeze(2)), 2)
        grid = grid.repeat(n, 1, 1, 1).type_as(input).to(input.device)
        grid = grid + delta.permute(0, 2, 3, 1) / norm

        output = F.grid_sample(input, grid)
        return output

    def bilinear_interpolate_torch_gridsample2(self, input, size, delta=0):
        out_h, out_w = size
        n, c, h, w = input.shape
        s = 2.0
        norm = torch.tensor([[[[(out_w-1)/s, (out_h-1)/s]]]]).type_as(input).to(input.device) # not [h/s, w/s]
        w_list = torch.linspace(-1.0, 1.0, out_h).view(-1, 1).repeat(1, out_w)
        h_list = torch.linspace(-1.0, 1.0, out_w).repeat(out_h, 1)
        grid = torch.cat((h_list.unsqueeze(2), w_list.unsqueeze(2)), 2)
        grid = grid.repeat(n, 1, 1, 1).type_as(input).to(input.device)
        grid = grid + delta.permute(0, 2, 3, 1) / norm

        output = F.grid_sample(input, grid, align_corners=True)
        return output

    def forward(self, low_stage, high_stage):
  
        h, w = low_stage.size(2), low_stage.size(3)
        #high_stage = F.interpolate(input=high_stage, size=(h, w), mode='bilinear', align_corners=True)
        
        concat = torch.cat((low_stage, high_stage), 1) #2,512,64,64
        off_sets=self.offset_generator(concat) #2,18,64,64
        high_stage_align=self.deform_conv(high_stage,off_sets)
        low_stage=high_stage_align+low_stage

        

        #low_stage=high_stage_gridsample+low_stage_gridsample+weight1*(high_stage+low_stage)
        #low_stage=weight1*(high_stage_gridsample+low_stage_gridsample)
        return low_stage


class CAB_inverse(nn.Module):
    def __init__(self, channel):
        super(CAB_inverse, self).__init__()
        self.channel_attention=ChannelAttention(channel)


    def forward(self, low_stage, high_stage):
        #print(low_stage.shape)
        #print(high_stage.shape)
        #concat = torch.cat((low_stage, high_stage),2)
        #print(concat.shape)
        
        weights=self.channel_attention(low_stage+high_stage)
        
        low_stage_weight=weights*low_stage
        high_stage_weight=weights*high_stage
        h0igh_stage=high_stage_weight+low_stage_weight+low_stage+high_stage
        return high_stage

