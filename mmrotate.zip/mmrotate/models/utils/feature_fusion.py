from torch import nn, Tensor
import torch
#parameters
class FeatureFusionLayer(nn.Module):

    def __init__(self, embed_dim, num_heads,dropout=0.1):
        super().__init__()
        self.self_attn1 = nn.MultiheadAttention(embed_dim, num_heads,batch_first=True,dropout=0.1)
        self.self_attn2 = nn.MultiheadAttention(embed_dim, num_heads,batch_first=True,dropout=0.1)
        self.cross_attn = nn.MultiheadAttention(embed_dim, num_heads,batch_first=True,dropout=0.1)
        #self.multihead_attn2 = nn.MultiheadAttention(embed_dim, num_heads)

        self.norm1 = nn.LayerNorm(embed_dim)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.norm21 = nn.LayerNorm(embed_dim)
        self.dropout21 = nn.Dropout(dropout)



    def forward(self, src1, src2): #src1:small size

        #cross_attention
        query=src2
        key=src1
        value=src1
        src21=self.cross_attn(query, key, value)[0]
        #src21 = self.norm21(src21)
        src21=src2+self.dropout21(src21)
        
    
        return src21
'''
embed_dim=256*1
num_heads=1
multihead=torch.nn.MultiheadAttention(embed_dim,num_heads,batch_first=True)
norm=torch.nn.LayerNorm(embed_dim)
#input
query=torch.randn(2,1024,embed_dim)
key=torch.randn(2,512,embed_dim)
value=torch.randn(2,512,embed_dim)
attn_output,attn_output_weights=multihead(query,key,value)
norm_output=norm(attn_output)
output=query+norm_output
print(attn_output.shape,attn_output_weights.shape,output.shape)
'''

'''
embed_dim=256*1
num_heads=1
feature_fusion=FeatureFusionLayer(embed_dim,num_heads)
src1=torch.randn(2,512,embed_dim)
src2=torch.randn(2,1024,embed_dim)
feature_final=feature_fusion(src1,src2)
print(feature_final.shape)
'''

'''
        q1 = k1 = src1
        q2 = k2 = src2
        src11 = self.self_attn1(q1, k1, value=src1)[0]
        src11=src1+src11
        src11 = self.norm1(src11)

        src22 = self.self_attn2(q2, k2, value=src2)[0]
        src22=src2+src22
        src22 = self.norm2(src22)
'''