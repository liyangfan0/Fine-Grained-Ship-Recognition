# Copyright (c) Facebook, Inc. and its affiliates.


def try_index(scalar_or_list, i):
    try:
        return scalar_or_list[i]
    except TypeError:
        return scalar_or_list
