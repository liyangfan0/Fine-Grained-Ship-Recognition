# Copyright (c) OpenMMLab. All rights reserved.
from .eval_map import eval_rbbox_map

__all__ = ['eval_rbbox_map']
